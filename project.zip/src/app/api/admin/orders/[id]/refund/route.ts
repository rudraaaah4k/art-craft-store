import { enforceRateLimit } from '@/lib/rate-limit'
import { NextResponse } from 'next/server'
import { getAdminApiSession } from '@/lib/admin'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

type Context = { params: Promise<{ id: string }> }
const orderIdSchema = z.string().trim().min(1).max(100)
const refundSchema = z.object({
  amountPaise: z.number().int().positive('Refund amount must be positive.').optional(),
  reason: z.enum(['duplicate', 'fraudulent', 'customer_request', 'other']).default('customer_request'),
  notes: z.string().max(200).optional(),
})

function hasRazorpayCredentials() {
  return Boolean(
    process.env.RAZORPAY_KEY_ID &&
    process.env.RAZORPAY_KEY_SECRET &&
    !process.env.RAZORPAY_KEY_ID.startsWith('your-')
  )
}

export async function POST(request: Request, { params }: Context) {
  if (!await enforceRateLimit(request, 'admin-write', 60)) return NextResponse.json({ message: 'Too many requests' }, { status: 429 })
  if (!await getAdminApiSession()) return NextResponse.json({ message: 'Forbidden' }, { status: 403 })
  const { id } = await params
  const parsedId = orderIdSchema.safeParse(id)
  const parsedBody = refundSchema.safeParse(await request.json().catch(() => ({})))
  if (!parsedId.success || !parsedBody.success) {
    return NextResponse.json({ message: 'Invalid refund request.', issues: parsedBody.success ? null : parsedBody.error.flatten() }, { status: 400 })
  }

  const order = await prisma.order.findUnique({
    where: { id: parsedId.data },
    include: { payment: true },
  })
  if (!order) return NextResponse.json({ message: 'Order not found.' }, { status: 404 })
  if (!order.payment) return NextResponse.json({ message: 'No payment found for this order.' }, { status: 400 })
  if (!['CAPTURED', 'PARTIALLY_REFUNDED'].includes(order.payment.status)) {
    return NextResponse.json({ message: 'Payment is not refundable in its current state.' }, { status: 400 })
  }

  // Idempotency: sum already-refunded amount from metadata
  const meta = order.payment.metadata && typeof order.payment.metadata === 'object' && !Array.isArray(order.payment.metadata)
    ? order.payment.metadata as Record<string, unknown>
    : {}
  const alreadyRefundedPaise: number = typeof meta.totalRefundedPaise === 'number' ? meta.totalRefundedPaise : 0
  const remainingPaise = order.payment.amountPaise - alreadyRefundedPaise
  if (remainingPaise <= 0) {
    return NextResponse.json({ message: 'Payment is already fully refunded.' }, { status: 400 })
  }

  const amountPaise = parsedBody.data.amountPaise ?? remainingPaise
  if (amountPaise > remainingPaise) {
    return NextResponse.json({
      message: `Refund amount (₹${(amountPaise / 100).toFixed(2)}) exceeds refundable balance (₹${(remainingPaise / 100).toFixed(2)}).`,
    }, { status: 400 })
  }

  let providerRefundId: string
  if (hasRazorpayCredentials() && order.payment.providerPaymentId) {
    const credentials = `${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`
    const response = await fetch(`https://api.razorpay.com/v1/payments/${order.payment.providerPaymentId}/refund`, {
      method: 'POST',
      headers: {
        Authorization: `Basic ${Buffer.from(credentials).toString('base64')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: amountPaise,
        notes: { reason: parsedBody.data.reason, notes: parsedBody.data.notes ?? '' },
      }),
    })
    if (!response.ok) {
      const err = await response.json().catch(() => ({})) as Record<string, unknown>
      const rzpError = err.error as { code?: string; description?: string; reason?: string } | undefined
      console.error('[refund] Razorpay refund failed', { status: response.status, paymentId: order.payment.providerPaymentId, error: err })
      const description = rzpError?.description ?? 'Razorpay refund failed.'
      return NextResponse.json({ message: description, razorpayError: rzpError ?? null }, { status: 502 })
    }
    const refundData = await response.json() as { id: string }
    providerRefundId = refundData.id
  } else {
    providerRefundId = `mock_refund_${Date.now()}`
  }

  const newTotalRefundedPaise = alreadyRefundedPaise + amountPaise
  const refunds = Array.isArray(meta.refunds) ? meta.refunds : []
  const isFullRefund = newTotalRefundedPaise >= order.payment.amountPaise

  const updatedPayment = await prisma.payment.update({
    where: { id: order.payment.id },
    data: {
      status: isFullRefund ? 'REFUNDED' : 'PARTIALLY_REFUNDED',
      metadata: {
        ...meta,
        totalRefundedPaise: newTotalRefundedPaise,
        refunds: [
          ...refunds,
          {
            refundId: providerRefundId,
            amountPaise,
            reason: parsedBody.data.reason,
            notes: parsedBody.data.notes ?? null,
            refundedAt: new Date().toISOString(),
          },
        ],
      },
    },
  })

  if (isFullRefund) {
    await prisma.order.update({ where: { id: order.id }, data: { status: 'REFUNDED', paymentStatus: 'REFUNDED' } })
  } else {
    await prisma.order.update({ where: { id: order.id }, data: { paymentStatus: 'PARTIALLY_REFUNDED' } })
  }

  return NextResponse.json({
    refundId: providerRefundId,
    amountPaise,
    totalRefundedPaise: newTotalRefundedPaise,
    remainingPaise: order.payment.amountPaise - newTotalRefundedPaise,
    paymentStatus: updatedPayment.status,
    status: updatedPayment.status,
    isFullRefund,
  })
}
